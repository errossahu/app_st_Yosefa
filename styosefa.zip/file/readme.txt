                         Visual Prolog 5.2
                          Personal Edition
                        Release Candidate 1
                           Release Notes
             (C) Copyright Prolog Development Center
                            March 1999


The Visual Prolog introduction and release notes are now supplied
as HTML files. You must have an Internet browser (NETSCAPE or
Microsoft Explorer) installed to read these files.

Please open the INTRO.HTM file to see the release notes.

To install Visual Prolog; start setup.exe in the install catalog.
