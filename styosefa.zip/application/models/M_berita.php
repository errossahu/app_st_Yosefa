<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_berita extends CI_Model {

	public function lists()
{
	$this->db->select('*');
	$this->db->from('tbl_berita');
	$this->db->join('user', 'user.id_user = tbl_berita.id_user', 'left');
	$this->db->order_by('id_berita', 'desc');

	return $this->db->get()->result();
	# code...
}
	
public function add($data)
{
	$this->db->insert('tbl_berita', $data);
}
public function detail($id_berita)
{

		$this->db->select('*');
		$this->db->from('tbl_berita');

		$this->db->where('id_berita',$id_berita);
		return $this->db->get()->row();

}	
public function edit($data)
{

	    $this->db->where('id_berita', $data['id_berita']);
	 	 $this->db->update('tbl_berita', $data);

}
public function delete($data)
{

	    $this->db->where('id_berita', $data['id_berita']);
	 	 $this->db->delete('tbl_berita', $data);

}

}

/* End of file M_berita.php */
/* Location: ./application/models/M_berita.php */