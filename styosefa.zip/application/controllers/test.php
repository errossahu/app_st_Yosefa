<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	public function index()
	{
	   $this->load->view('admin/layout/v_nav');
		
	}

}

/* End of file test.php */
/* Location: ./application/controllers/test.php */