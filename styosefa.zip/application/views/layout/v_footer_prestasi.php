	<script src="<?=base_url()?>template/table/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=base_url()?>template/table/vendor/bootstrap/js/popper.js"></script>
	<script src="<?=base_url()?>template/table/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=base_url()?>template/table/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=base_url()?>template/table/js/main.js"></script>

</body>
</html>