<body>
<?php

	
	$setting= $this->m_setting->detail_nama();

?>
<div  class="super_container">

	<!-- Header -->

	<header  class="header">
			
		<!-- Top Bar -->
		<div style="background-color: #ffff00;" class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div style="color: black" class="question">Have any questions?</div></li>
									<li>
										<i  style="color: black" class="fa fa-phone" aria-hidden="true"></i>
										<div  style="color: black">xxxxxxxxxxxxxxxxxxxx</div>
									</li>
									<li>
										<i  style="color: black" class="fa fa-envelope-o" aria-hidden="true"></i>
										<div  style="color: black">duragonprojek@gmail.com</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="<?=base_Url('login') ?>">Login</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>
		