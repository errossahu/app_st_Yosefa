<?php

require_once('v_head_home.php');
require_once('v_header.php');
require_once('v_nav.php');
require_once('v_content.php');
require_once('v_footer_home.php');
?>