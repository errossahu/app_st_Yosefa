     <!-- /.navbar-top-links -->

                <div style="margin-top: 0px" class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                           
                            <li>
                                <a href="<?=base_Url('admin')?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                            <li>
                                <a href="<?=base_Url('mapel')?>"><i class="fa fa-table"></i> Mata Pelajaran  </a>
                             
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <a href="<?=base_Url('guru')?>"><i class="fa fa-users"></i> Guru</a>
                            </li>
                            
                            <li>
                                <a href="<?=base_Url('siswa')?>"><i class="fa fa-mortar-board"></i>Siswa</a>

                            </li>
                            <li>
                                <a href="<?=base_Url('pengumuman')?>"><i class="fa fa-file fa-fw"></i>Pengumuman</a>

                            </li>
                            <li>
                                <a href="<?=base_Url('berita')?>"><i class="fa fa-newspaper-o fa-fw"></i>Berita</a>


                            </li>
                            <li>
                                <a href="<?=base_Url('gallery')?>"><i class="fa fa-image fa-fw"></i>Gallery</a>


                            </li>
                            
                                                        <li>
                                <a href="<?=base_Url('download')?>"><i class="fa fa-download fa-fw"></i>Download</a>


                            </li>
                              <li>
                                <a href="<?=base_Url('setting')?>"><i class="fa fa-gear fa-fw"></i>Setting</a>


                            </li>
                              <li>
                                <a href="<?=base_Url('ekstra')?>"><i  class="fa fa-futbol-o  fa-fw"></i>Ekstra</a>
        

                            </li>
                               <li>
                                <a href="<?=base_Url('prestasi')?>"><i  class="fa fa-trophy  fa-fw"></i>Prestasi</a>


                            </li>
                                                           <li>
                                <a href="<?=base_Url('kurikulum')?>"><i  class="fas fa-book-open  fa-fw"></i>Kurikulum</a>


                            </li>

                            </li>
                                                           <li>
                                <a href="<?=base_Url('jadwal')?>"><i  class="fa fa-calendar  fa-fw"></i>Jadwal</a>


                            </li>
                             </li>
                                                           <li>
                                <a href="<?=base_Url('fasilitas')?>"><i  class="fa fa-building-o  fa-fw"></i>Fasilitas</a>


                            </li>



                                                        
                            
                            <br><br><br>
                           
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header"><?=$title2?></h1>
                      