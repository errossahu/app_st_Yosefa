<h1>Aturan Penggunaan Menu Admin</h1>
<ul>
	<li>1.Jangan Gunakan Tombol Browsur Untuk Kembali.Gunakan Tombol Menu  Yang  Tersedia di web ini </li>
	<li>2.Untuk Menu Admin Jangan Diakses Lebih Dari 1 Orang. Nanti database nya bertabrakan datanya</li>
	</ul>