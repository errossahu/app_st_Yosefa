    	<div style="height: 170px" class="home">
    <div class="breadcrumbs_container">
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="breadcrumbs">
              <ul>
                <li><a href="<?=base_Url('home')?>">Home</a></li>
                <li><a href="<?=base_Url('home/berita')?>">berita</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>      
  </div>
  <div class="contact">
    
      <!-- google maps -->
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3946.0651073297227!2d119.89242971424727!3d-8.493050893893727!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2db465c5292d8bd9%3A0x1f5346abe9f1b831!2sSMPK%20Sta.YOSEFA_%20LABUAN%20BAJO!5e0!3m2!1sid!2sid!4v1593152705101!5m2!1sid!2sid" width="99%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>